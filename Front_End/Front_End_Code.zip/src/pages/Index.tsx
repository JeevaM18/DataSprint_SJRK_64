import { SurvivalGame } from '@/components/SurvivalGame';

const Index = () => {
  return <SurvivalGame />;
};

export default Index;
